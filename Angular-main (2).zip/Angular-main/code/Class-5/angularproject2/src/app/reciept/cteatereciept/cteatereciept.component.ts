import { Component } from '@angular/core';

@Component({
  selector: 'app-cteatereciept',
  templateUrl: './cteatereciept.component.html',
  styleUrl: './cteatereciept.component.css'
})
export class CteaterecieptComponent {

}
