export interface Beneficiary {
  id?: number;
  beneficiariesName: string;
  beneficiariesAddress: string;
  beneficiariesPhone: string;
  beneficiariesEmail: string;
  beneficiariesRelationship: string;
  beneficiariesIdNumber: string;
}
