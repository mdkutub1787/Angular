export interface Document {
  id?: number;
  documentPath: string;
}
