export interface Client {
  id?: number;
  name: string;
  address: string;
  phone: string;
  email: string;
  nextOfKin: string;
  nextOfKinPhone: string;
  nextOfKinEmail: string;
}
