import { Component } from '@angular/core';

@Component({
  selector: 'app-kutub',
  standalone: true,
  imports: [],
  templateUrl: './kutub.component.html',
  styleUrl: './kutub.component.css'
})
export class KutubComponent {

}
